function night_remove_horizon(filename)




