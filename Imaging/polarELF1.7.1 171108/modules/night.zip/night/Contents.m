% Contents of folder "NIGHT"
% 
% Dependencies: nanmean  - Statistics and Machine Learning Toolbox
%
% Files
%   elf_analysis                 - calculates intensity and spatial descriptors for a single image.
